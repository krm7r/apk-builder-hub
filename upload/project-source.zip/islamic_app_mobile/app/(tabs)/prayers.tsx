import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
  Alert,
} from "react-native";
import { colors } from "@/app/constants/colors";
import { formatTime, calculateTimeUntilPrayer } from "@/app/utils/helpers";
import { prayerNames } from "@/app/data/islamicData";

const { width } = Dimensions.get("window");

// أوقات الصلاة النموذجية (يمكن تحديثها بناءً على الموقع الجغرافي)
const defaultPrayerTimes = [
  { name: "الفجر", time: { hours: 5, minutes: 30 } },
  { name: "الظهر", time: { hours: 12, minutes: 15 } },
  { name: "العصر", time: { hours: 15, minutes: 45 } },
  { name: "المغرب", time: { hours: 18, minutes: 30 } },
  { name: "العشاء", time: { hours: 20, minutes: 0 } },
];

export default function PrayersScreen() {
  const [prayerTimes, setPrayerTimes] = useState(defaultPrayerTimes);
  const [nextPrayer, setNextPrayer] = useState(null);
  const [timeUntilPrayer, setTimeUntilPrayer] = useState(null);

  useEffect(() => {
    // تحديث الصلاة القادمة
    const updateNextPrayer = () => {
      const now = new Date();
      const currentHours = now.getHours();
      const currentMinutes = now.getMinutes();

      let next = null;
      for (let prayer of prayerTimes) {
        if (
          prayer.time.hours > currentHours ||
          (prayer.time.hours === currentHours &&
            prayer.time.minutes > currentMinutes)
        ) {
          next = prayer;
          break;
        }
      }

      if (!next) {
        next = prayerTimes[0]; // الفجر في اليوم التالي
      }

      setNextPrayer(next);
      setTimeUntilPrayer(calculateTimeUntilPrayer(next.time));
    };

    updateNextPrayer();
    const interval = setInterval(updateNextPrayer, 1000);

    return () => clearInterval(interval);
  }, [prayerTimes]);

  const handleLocationRequest = () => {
    Alert.alert(
      "الموقع الجغرافي",
      "لتحديث أوقات الصلاة بناءً على موقعك، يرجى تفعيل خدمة الموقع",
      [
        { text: "إلغاء", onPress: () => {} },
        {
          text: "تفعيل",
          onPress: () => {
            // هنا يتم طلب الموقع الجغرافي
            Alert.alert("تم", "تم طلب الموقع الجغرافي");
          },
        },
      ]
    );
  };

  return (
    <View style={styles.container}>
      {/* رأس الصفحة */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>أوقات الصلاة</Text>
        <Text style={styles.headerSubtitle}>الصلوات الخمس</Text>
      </View>

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* الصلاة القادمة */}
        {nextPrayer && timeUntilPrayer && (
          <View style={styles.nextPrayerCard}>
            <Text style={styles.nextPrayerLabel}>الصلاة القادمة</Text>
            <Text style={styles.nextPrayerName}>{nextPrayer.name}</Text>
            <View style={styles.countdownContainer}>
              <View style={styles.countdownItem}>
                <Text style={styles.countdownNumber}>
                  {String(timeUntilPrayer.hours).padStart(2, "0")}
                </Text>
                <Text style={styles.countdownLabel}>ساعة</Text>
              </View>
              <Text style={styles.countdownSeparator}>:</Text>
              <View style={styles.countdownItem}>
                <Text style={styles.countdownNumber}>
                  {String(timeUntilPrayer.minutes).padStart(2, "0")}
                </Text>
                <Text style={styles.countdownLabel}>دقيقة</Text>
              </View>
              <Text style={styles.countdownSeparator}>:</Text>
              <View style={styles.countdownItem}>
                <Text style={styles.countdownNumber}>
                  {String(timeUntilPrayer.seconds).padStart(2, "0")}
                </Text>
                <Text style={styles.countdownLabel}>ثانية</Text>
              </View>
            </View>
          </View>
        )}

        {/* قائمة أوقات الصلاة */}
        <Text style={styles.sectionTitle}>أوقات الصلوات</Text>
        <View style={styles.prayersList}>
          {prayerTimes.map((prayer, index) => {
            const isNext = nextPrayer?.name === prayer.name;
            return (
              <View
                key={index}
                style={[
                  styles.prayerItem,
                  isNext && styles.nextPrayerItem,
                ]}
              >
                <View style={styles.prayerInfo}>
                  <Text style={styles.prayerName}>{prayer.name}</Text>
                  <Text style={styles.prayerTime}>
                    {formatTime(prayer.time.hours, prayer.time.minutes)}
                  </Text>
                </View>
                {isNext && (
                  <View style={styles.nextBadge}>
                    <Text style={styles.nextBadgeText}>القادمة</Text>
                  </View>
                )}
              </View>
            );
          })}
        </View>

        {/* زر تحديث الموقع */}
        <TouchableOpacity
          style={styles.locationButton}
          onPress={handleLocationRequest}
          activeOpacity={0.7}
        >
          <Text style={styles.locationButtonText}>📍 تحديث الموقع الجغرافي</Text>
        </TouchableOpacity>

        {/* معلومات إضافية */}
        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>معلومات مهمة</Text>
          <Text style={styles.infoText}>
            أوقات الصلاة المعروضة هي أوقات تقريبية. يرجى تفعيل خدمة الموقع الجغرافي للحصول على أوقات دقيقة بناءً على موقعك.
          </Text>
          <Text style={styles.infoText}>
            تذكر أن أوقات الصلاة تختلف حسب الموقع الجغرافي والفصل من السنة.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 20,
    backgroundColor: colors.primary,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: "700",
    color: colors.text,
    marginBottom: 5,
    textAlign: "right",
  },
  headerSubtitle: {
    fontSize: 13,
    color: colors.textSecondary,
    textAlign: "right",
  },
  scrollContent: {
    paddingBottom: 30,
  },
  nextPrayerCard: {
    marginHorizontal: 15,
    marginTop: 20,
    padding: 25,
    backgroundColor: colors.surface,
    borderRadius: 15,
    borderLeftWidth: 4,
    borderLeftColor: colors.secondary,
    alignItems: "center",
  },
  nextPrayerLabel: {
    fontSize: 12,
    color: colors.textSecondary,
    marginBottom: 8,
    fontWeight: "600",
  },
  nextPrayerName: {
    fontSize: 28,
    fontWeight: "700",
    color: colors.secondary,
    marginBottom: 20,
  },
  countdownContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  countdownItem: {
    alignItems: "center",
  },
  countdownNumber: {
    fontSize: 32,
    fontWeight: "700",
    color: colors.primary,
  },
  countdownLabel: {
    fontSize: 11,
    color: colors.textSecondary,
    marginTop: 3,
  },
  countdownSeparator: {
    fontSize: 24,
    color: colors.primary,
    marginHorizontal: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: colors.text,
    marginHorizontal: 15,
    marginTop: 25,
    marginBottom: 15,
    textAlign: "right",
  },
  prayersList: {
    marginHorizontal: 15,
    marginBottom: 20,
  },
  prayerItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: 15,
    marginBottom: 10,
    borderLeftWidth: 3,
    borderLeftColor: colors.primary,
  },
  nextPrayerItem: {
    backgroundColor: colors.surfaceLight,
    borderLeftColor: colors.secondary,
  },
  prayerInfo: {
    flex: 1,
  },
  prayerName: {
    fontSize: 16,
    fontWeight: "600",
    color: colors.text,
    marginBottom: 3,
  },
  prayerTime: {
    fontSize: 14,
    color: colors.secondary,
    fontWeight: "700",
  },
  nextBadge: {
    backgroundColor: colors.secondary,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  nextBadgeText: {
    fontSize: 11,
    fontWeight: "700",
    color: colors.background,
  },
  locationButton: {
    marginHorizontal: 15,
    marginBottom: 20,
    paddingVertical: 15,
    backgroundColor: colors.primary,
    borderRadius: 12,
    alignItems: "center",
  },
  locationButtonText: {
    fontSize: 14,
    fontWeight: "700",
    color: colors.text,
  },
  infoCard: {
    marginHorizontal: 15,
    marginBottom: 20,
    padding: 18,
    backgroundColor: colors.surfaceLight,
    borderRadius: 15,
    borderTopWidth: 2,
    borderTopColor: colors.accent,
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: colors.accent,
    marginBottom: 12,
    textAlign: "right",
  },
  infoText: {
    fontSize: 13,
    color: colors.textSecondary,
    lineHeight: 20,
    marginBottom: 10,
    textAlign: "right",
  },
});

