import { StyleSheet, Text, View } from "react-native";

import { colors } from "@/app/constants/colors";

export default function ExploreScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>معلومات التطبيق</Text>
      <Text style={styles.text}>اختر إحدى الأدوات الإسلامية من شريط التنقل.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
    backgroundColor: colors.background,
  },
  title: {
    marginBottom: 12,
    fontSize: 22,
    fontWeight: "700",
    color: colors.secondary,
  },
  text: {
    fontSize: 15,
    color: colors.textSecondary,
    textAlign: "center",
  },
});
