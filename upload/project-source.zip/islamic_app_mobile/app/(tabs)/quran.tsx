import React, { useState } from "react";
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  TextInput,
  Dimensions,
} from "react-native";
import { colors } from "@/app/constants/colors";
import { quranChapters } from "@/app/data/islamicData";

const { width } = Dimensions.get("window");

export default function QuranScreen() {
  const [selectedChapter, setSelectedChapter] = useState(null);
  const [searchText, setSearchText] = useState("");

  const filteredChapters = quranChapters.filter(
    (chapter) =>
      chapter.name.includes(searchText) ||
      chapter.id.toString().includes(searchText)
  );

  const renderChapterItem = ({ item }) => (
    <TouchableOpacity
      style={[
        styles.chapterItem,
        selectedChapter?.id === item.id && styles.selectedChapter,
      ]}
      onPress={() => setSelectedChapter(item)}
      activeOpacity={0.7}
    >
      <View style={styles.chapterNumber}>
        <Text style={styles.chapterNumberText}>{item.id}</Text>
      </View>
      <View style={styles.chapterInfo}>
        <Text style={styles.chapterName}>{item.name}</Text>
        <Text style={styles.chapterDetails}>
          {item.verses} آية • {item.revelation}
        </Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      {/* رأس الصفحة */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>القرآن الكريم</Text>
        <Text style={styles.headerSubtitle}>30 جزء • 114 سورة • 6236 آية</Text>
      </View>

      {/* شريط البحث */}
      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="ابحث عن سورة..."
          placeholderTextColor={colors.textTertiary}
          value={searchText}
          onChangeText={setSearchText}
        />
      </View>

      {/* قائمة السور */}
      <FlatList
        data={filteredChapters}
        renderItem={renderChapterItem}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={styles.listContent}
        scrollEnabled={true}
      />

      {/* تفاصيل السورة المختارة */}
      {selectedChapter && (
        <View style={styles.detailsContainer}>
          <Text style={styles.detailsTitle}>{selectedChapter.name}</Text>
          <View style={styles.detailsInfo}>
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>الآيات</Text>
              <Text style={styles.detailValue}>{selectedChapter.verses}</Text>
            </View>
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>النوع</Text>
              <Text style={styles.detailValue}>{selectedChapter.revelation}</Text>
            </View>
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>الرقم</Text>
              <Text style={styles.detailValue}>{selectedChapter.id}</Text>
            </View>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 20,
    backgroundColor: colors.primary,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: "700",
    color: colors.text,
    marginBottom: 5,
    textAlign: "right",
  },
  headerSubtitle: {
    fontSize: 13,
    color: colors.textSecondary,
    textAlign: "right",
  },
  searchContainer: {
    paddingHorizontal: 15,
    paddingVertical: 15,
    backgroundColor: colors.surface,
  },
  searchInput: {
    backgroundColor: colors.surfaceLight,
    borderRadius: 10,
    paddingHorizontal: 15,
    paddingVertical: 12,
    color: colors.text,
    textAlign: "right",
    borderWidth: 1,
    borderColor: colors.primary,
  },
  listContent: {
    paddingHorizontal: 15,
    paddingTop: 10,
    paddingBottom: 20,
  },
  chapterItem: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: 15,
    marginBottom: 10,
    borderLeftWidth: 3,
    borderLeftColor: colors.primary,
  },
  selectedChapter: {
    backgroundColor: colors.surfaceLight,
    borderLeftColor: colors.secondary,
  },
  chapterNumber: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: colors.primary,
    justifyContent: "center",
    alignItems: "center",
    marginLeft: 10,
  },
  chapterNumberText: {
    fontSize: 16,
    fontWeight: "700",
    color: colors.text,
  },
  chapterInfo: {
    flex: 1,
    marginRight: 10,
  },
  chapterName: {
    fontSize: 16,
    fontWeight: "600",
    color: colors.text,
    textAlign: "right",
    marginBottom: 3,
  },
  chapterDetails: {
    fontSize: 12,
    color: colors.textSecondary,
    textAlign: "right",
  },
  detailsContainer: {
    backgroundColor: colors.surface,
    borderTopWidth: 1,
    borderTopColor: colors.surfaceLight,
    padding: 15,
  },
  detailsTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: colors.secondary,
    marginBottom: 15,
    textAlign: "right",
  },
  detailsInfo: {
    flexDirection: "row",
    justifyContent: "space-around",
  },
  detailItem: {
    alignItems: "center",
  },
  detailLabel: {
    fontSize: 12,
    color: colors.textSecondary,
    marginBottom: 5,
  },
  detailValue: {
    fontSize: 18,
    fontWeight: "700",
    color: colors.primary,
  },
});
