import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
  Alert,
  ScrollView,
} from "react-native";
import { colors } from "@/app/constants/colors";
import { calculateQiblaDirection } from "@/app/utils/helpers";

const { width, height } = Dimensions.get("window");

export default function QiblaScreen() {
  const [qiblaDirection, setQiblaDirection] = useState(0);
  const [userLocation, setUserLocation] = useState(null);
  const [hasPermission, setHasPermission] = useState(false);

  // الموقع الافتراضي (مكة المكرمة)
  const defaultLocation = { latitude: 21.4225, longitude: 39.8262 };

  // الموقع الحالي (للتجربة)
  const currentLocation = { latitude: 30.0444, longitude: 31.2357 }; // القاهرة

  useEffect(() => {
    // حساب اتجاه القبلة
    const direction = calculateQiblaDirection(
      currentLocation.latitude,
      currentLocation.longitude
    );
    setQiblaDirection(direction);
    setUserLocation(currentLocation);
  }, []);

  const handleRequestLocation = () => {
    Alert.alert(
      "الموقع الجغرافي",
      "لتحديد اتجاه القبلة بدقة، يرجى السماح بالوصول إلى موقعك",
      [
        { text: "إلغاء", onPress: () => {} },
        {
          text: "السماح",
          onPress: () => {
            setHasPermission(true);
            Alert.alert("تم", "تم الوصول إلى موقعك بنجاح");
          },
        },
      ]
    );
  };

  const getDirectionName = (degrees) => {
    if (degrees < 22.5 || degrees >= 337.5) return "شمال";
    if (degrees < 67.5) return "شمال شرق";
    if (degrees < 112.5) return "شرق";
    if (degrees < 157.5) return "جنوب شرق";
    if (degrees < 202.5) return "جنوب";
    if (degrees < 247.5) return "جنوب غرب";
    if (degrees < 292.5) return "غرب";
    return "شمال غرب";
  };

  return (
    <View style={styles.container}>
      {/* رأس الصفحة */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>بوصلة القبلة</Text>
        <Text style={styles.headerSubtitle}>حدد اتجاه مكة المكرمة</Text>
      </View>

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* البوصلة */}
        <View style={styles.compassContainer}>
          <View style={styles.compass}>
            {/* الاتجاهات الأساسية */}
            <View style={styles.directionLabels}>
              <Text style={styles.directionLabel}>شمال</Text>
              <Text style={[styles.directionLabel, { right: 10 }]}>شرق</Text>
              <Text style={[styles.directionLabel, { bottom: 10 }]}>جنوب</Text>
              <Text style={[styles.directionLabel, { left: 10 }]}>غرب</Text>
            </View>

            {/* إبرة القبلة */}
            <View
              style={[
                styles.needle,
                {
                  transform: [
                    { rotate: `${qiblaDirection}deg` },
                  ],
                },
              ]}
            >
              <View style={styles.needleTop} />
              <View style={styles.needleBottom} />
            </View>

            {/* مركز البوصلة */}
            <View style={styles.center}>
              <Text style={styles.centerText}>🕌</Text>
            </View>
          </View>
        </View>

        {/* معلومات الاتجاه */}
        <View style={styles.directionInfo}>
          <Text style={styles.directionDegrees}>{Math.round(qiblaDirection)}°</Text>
          <Text style={styles.directionName}>{getDirectionName(qiblaDirection)}</Text>
        </View>

        {/* معلومات الموقع */}
        {userLocation && (
          <View style={styles.locationCard}>
            <Text style={styles.locationTitle}>موقعك الحالي</Text>
            <View style={styles.locationInfo}>
              <View style={styles.locationItem}>
                <Text style={styles.locationLabel}>خط العرض</Text>
                <Text style={styles.locationValue}>
                  {userLocation.latitude.toFixed(4)}°
                </Text>
              </View>
              <View style={styles.locationItem}>
                <Text style={styles.locationLabel}>خط الطول</Text>
                <Text style={styles.locationValue}>
                  {userLocation.longitude.toFixed(4)}°
                </Text>
              </View>
            </View>
          </View>
        )}

        {/* زر تحديث الموقع */}
        <TouchableOpacity
          style={styles.updateButton}
          onPress={handleRequestLocation}
          activeOpacity={0.7}
        >
          <Text style={styles.updateButtonText}>📍 تحديث الموقع</Text>
        </TouchableOpacity>

        {/* معلومات إضافية */}
        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>معلومات مهمة</Text>
          <Text style={styles.infoText}>
            هذه البوصلة تساعدك على تحديد اتجاه القبلة (اتجاه الكعبة المشرفة) بناءً على موقعك الجغرافي.
          </Text>
          <Text style={styles.infoText}>
            تأكد من تفعيل خدمة الموقع الجغرافي للحصول على أدق النتائج.
          </Text>
          <Text style={styles.infoText}>
            الكعبة المشرفة تقع في مكة المكرمة بالمملكة العربية السعودية.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 20,
    backgroundColor: colors.primary,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: "700",
    color: colors.text,
    marginBottom: 5,
    textAlign: "right",
  },
  headerSubtitle: {
    fontSize: 13,
    color: colors.textSecondary,
    textAlign: "right",
  },
  scrollContent: {
    paddingBottom: 30,
    alignItems: "center",
  },
  compassContainer: {
    marginTop: 30,
    marginBottom: 30,
    alignItems: "center",
  },
  compass: {
    width: 280,
    height: 280,
    borderRadius: 140,
    backgroundColor: colors.surface,
    borderWidth: 3,
    borderColor: colors.primary,
    justifyContent: "center",
    alignItems: "center",
    position: "relative",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  directionLabels: {
    position: "absolute",
    width: "100%",
    height: "100%",
    justifyContent: "space-between",
    alignItems: "center",
  },
  directionLabel: {
    fontSize: 14,
    fontWeight: "700",
    color: colors.secondary,
    position: "absolute",
  },
  needle: {
    width: 6,
    height: 140,
    position: "absolute",
    justifyContent: "space-between",
    alignItems: "center",
  },
  needleTop: {
    width: 6,
    height: 70,
    backgroundColor: colors.secondary,
    borderRadius: 3,
  },
  needleBottom: {
    width: 6,
    height: 70,
    backgroundColor: colors.textTertiary,
    borderRadius: 3,
  },
  center: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: colors.primary,
    justifyContent: "center",
    alignItems: "center",
    zIndex: 10,
  },
  centerText: {
    fontSize: 32,
  },
  directionInfo: {
    alignItems: "center",
    marginBottom: 30,
  },
  directionDegrees: {
    fontSize: 36,
    fontWeight: "700",
    color: colors.secondary,
    marginBottom: 5,
  },
  directionName: {
    fontSize: 18,
    color: colors.text,
    fontWeight: "600",
  },
  locationCard: {
    width: "90%",
    marginBottom: 20,
    padding: 18,
    backgroundColor: colors.surface,
    borderRadius: 15,
    borderLeftWidth: 4,
    borderLeftColor: colors.secondary,
  },
  locationTitle: {
    fontSize: 14,
    fontWeight: "600",
    color: colors.secondary,
    marginBottom: 15,
    textAlign: "right",
  },
  locationInfo: {
    flexDirection: "row",
    justifyContent: "space-around",
  },
  locationItem: {
    alignItems: "center",
  },
  locationLabel: {
    fontSize: 12,
    color: colors.textSecondary,
    marginBottom: 5,
  },
  locationValue: {
    fontSize: 14,
    fontWeight: "700",
    color: colors.primary,
  },
  updateButton: {
    width: "90%",
    paddingVertical: 15,
    backgroundColor: colors.primary,
    borderRadius: 12,
    alignItems: "center",
    marginBottom: 20,
  },
  updateButtonText: {
    fontSize: 14,
    fontWeight: "700",
    color: colors.text,
  },
  infoCard: {
    width: "90%",
    padding: 18,
    backgroundColor: colors.surfaceLight,
    borderRadius: 15,
    borderTopWidth: 2,
    borderTopColor: colors.accent,
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: colors.accent,
    marginBottom: 12,
    textAlign: "right",
  },
  infoText: {
    fontSize: 13,
    color: colors.textSecondary,
    lineHeight: 20,
    marginBottom: 10,
    textAlign: "right",
  },
});

