import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  StatusBar,
} from "react-native";
import { colors } from "@/app/constants/colors";
import { formatDateArabic, gregorianToHijri, formatHijriDateArabic } from "@/app/utils/helpers";
import { dailyHadith, prayerNames } from "@/app/data/islamicData";

const { width } = Dimensions.get("window");

export default function HomeScreen() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [hijriDate, setHijriDate] = useState({ year: 0, month: 0, day: 0 });
  const [randomHadith, setRandomHadith] = useState(dailyHadith[0]);

  useEffect(() => {
    setCurrentDate(new Date());
    const hijri = gregorianToHijri(new Date());
    setHijriDate(hijri);

    // اختيار حديث عشوائي
    const randomIndex = Math.floor(Math.random() * dailyHadith.length);
    setRandomHadith(dailyHadith[randomIndex]);
  }, []);

  const quickAccessItems = [
    { id: 1, name: "القرآن الكريم", icon: "📖", route: "quran" },
    { id: 2, name: "أوقات الصلاة", icon: "⏰", route: "prayers" },
    { id: 3, name: "بوصلة القبلة", icon: "🧭", route: "qibla" },
    { id: 4, name: "الأذكار", icon: "📿", route: "adhkar" },
    { id: 5, name: "التقويم الهجري", icon: "📅", route: "hijri" },
    { id: 6, name: "الأسماء الحسنى", icon: "✨", route: "asma" },
  ];

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={colors.primary} />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {/* رأس الصفحة */}
        <View style={styles.header}>
          <Text style={styles.greeting}>السلام عليكم ورحمة الله</Text>
          <Text style={styles.date}>{formatDateArabic(currentDate)}</Text>
          <Text style={styles.hijriDate}>
            {formatHijriDateArabic(hijriDate.year, hijriDate.month, hijriDate.day)}
          </Text>
        </View>

        {/* الحديث اليومي */}
        <View style={styles.hadithCard}>
          <Text style={styles.hadithTitle}>الحديث الشريف اليومي</Text>
          <Text style={styles.hadithText}>{randomHadith.text}</Text>
          <View style={styles.hadithFooter}>
            <Text style={styles.hadithSource}>{randomHadith.source}</Text>
            <Text style={styles.hadithNarrator}>• {randomHadith.narrator}</Text>
          </View>
        </View>

        {/* الوصول السريع */}
        <Text style={styles.sectionTitle}>الميزات الرئيسية</Text>
        <View style={styles.quickAccessGrid}>
          {quickAccessItems.map((item) => (
            <TouchableOpacity
              key={item.id}
              style={styles.quickAccessItem}
              activeOpacity={0.7}
            >
              <Text style={styles.quickAccessIcon}>{item.icon}</Text>
              <Text style={styles.quickAccessName}>{item.name}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* معلومات إضافية */}
        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>معلومات مهمة</Text>
          <Text style={styles.infoText}>
            هذا التطبيق الإسلامي الشامل يوفر لك جميع الأدوات التي تحتاجها للعبادة والتقرب إلى الله في حياتك اليومية.
          </Text>
          <Text style={styles.infoText}>
            استمتع بالقرآن الكريم والأذكار وأوقات الصلاة وغيرها من الميزات الرائعة.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollContent: {
    paddingBottom: 30,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 30,
    backgroundColor: colors.primary,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
  },
  greeting: {
    fontSize: 24,
    fontWeight: "700",
    color: colors.text,
    marginBottom: 10,
    textAlign: "right",
  },
  date: {
    fontSize: 14,
    color: colors.textSecondary,
    marginBottom: 5,
    textAlign: "right",
  },
  hijriDate: {
    fontSize: 14,
    color: colors.secondary,
    fontWeight: "600",
    textAlign: "right",
  },
  hadithCard: {
    marginHorizontal: 15,
    marginTop: 25,
    padding: 18,
    backgroundColor: colors.surface,
    borderRadius: 15,
    borderLeftWidth: 4,
    borderLeftColor: colors.secondary,
  },
  hadithTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: colors.secondary,
    marginBottom: 12,
    textAlign: "right",
  },
  hadithText: {
    fontSize: 13,
    color: colors.text,
    lineHeight: 22,
    marginBottom: 15,
    textAlign: "right",
  },
  hadithFooter: {
    flexDirection: "row",
    justifyContent: "flex-end",
    alignItems: "center",
  },
  hadithSource: {
    fontSize: 12,
    color: colors.textSecondary,
    fontWeight: "600",
  },
  hadithNarrator: {
    fontSize: 12,
    color: colors.textTertiary,
    marginLeft: 10,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: colors.text,
    marginHorizontal: 15,
    marginTop: 30,
    marginBottom: 15,
    textAlign: "right",
  },
  quickAccessGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    paddingHorizontal: 15,
    marginBottom: 20,
  },
  quickAccessItem: {
    width: (width - 45) / 2,
    aspectRatio: 1.2,
    backgroundColor: colors.surfaceLight,
    borderRadius: 15,
    padding: 15,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 12,
    borderWidth: 1,
    borderColor: colors.primary,
  },
  quickAccessIcon: {
    fontSize: 40,
    marginBottom: 10,
  },
  quickAccessName: {
    fontSize: 13,
    fontWeight: "600",
    color: colors.text,
    textAlign: "center",
  },
  infoCard: {
    marginHorizontal: 15,
    marginTop: 20,
    padding: 18,
    backgroundColor: colors.surfaceLight,
    borderRadius: 15,
    borderTopWidth: 2,
    borderTopColor: colors.accent,
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: colors.accent,
    marginBottom: 12,
    textAlign: "right",
  },
  infoText: {
    fontSize: 13,
    color: colors.textSecondary,
    lineHeight: 20,
    marginBottom: 10,
    textAlign: "right",
  },
});
