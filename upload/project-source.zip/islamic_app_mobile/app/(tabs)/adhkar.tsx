import React, { useState } from "react";
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Alert,
} from "react-native";
import { colors } from "@/app/constants/colors";
import { morningAdhkar, eveningAdhkar } from "@/app/data/islamicData";

const { width } = Dimensions.get("window");

export default function AdhkarScreen() {
  const [activeTab, setActiveTab] = useState("morning");
  const [counter, setCounter] = useState(0);
  const [selectedAdhkar, setSelectedAdhkar] = useState(null);

  const adhkarList = activeTab === "morning" ? morningAdhkar : eveningAdhkar;

  const handleAdhkarPress = (adhkar) => {
    setSelectedAdhkar(adhkar);
    setCounter(0);
  };

  const handleIncrement = () => {
    if (selectedAdhkar && counter < selectedAdhkar.count) {
      setCounter(counter + 1);
    } else if (selectedAdhkar && counter === selectedAdhkar.count) {
      Alert.alert("تم!", `تم إكمال ${selectedAdhkar.count} مرات من هذا الذكر`);
    }
  };

  const handleReset = () => {
    setCounter(0);
  };

  return (
    <View style={styles.container}>
      {/* رأس الصفحة */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>الأذكار</Text>
        <Text style={styles.headerSubtitle}>أذكار الصباح والمساء</Text>
      </View>

      {/* التبويبات */}
      <View style={styles.tabsContainer}>
        <TouchableOpacity
          style={[styles.tab, activeTab === "morning" && styles.activeTab]}
          onPress={() => {
            setActiveTab("morning");
            setSelectedAdhkar(null);
            setCounter(0);
          }}
        >
          <Text
            style={[
              styles.tabText,
              activeTab === "morning" && styles.activeTabText,
            ]}
          >
            أذكار الصباح
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === "evening" && styles.activeTab]}
          onPress={() => {
            setActiveTab("evening");
            setSelectedAdhkar(null);
            setCounter(0);
          }}
        >
          <Text
            style={[
              styles.tabText,
              activeTab === "evening" && styles.activeTabText,
            ]}
          >
            أذكار المساء
          </Text>
        </TouchableOpacity>
      </View>

      {/* قائمة الأذكار */}
      <ScrollView
        contentContainerStyle={styles.adhkarListContainer}
        showsVerticalScrollIndicator={false}
      >
        {adhkarList.map((adhkar) => (
          <TouchableOpacity
            key={adhkar.id}
            style={[
              styles.adhkarItem,
              selectedAdhkar?.id === adhkar.id && styles.selectedAdhkar,
            ]}
            onPress={() => handleAdhkarPress(adhkar)}
            activeOpacity={0.7}
          >
            <Text style={styles.adhkarText}>{adhkar.text}</Text>
            <View style={styles.adhkarFooter}>
              <Text style={styles.countText}>
                {adhkar.count} {adhkar.count === 1 ? "مرة" : "مرات"}
              </Text>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* عداد التسبيح */}
      {selectedAdhkar && (
        <View style={styles.counterContainer}>
          <Text style={styles.counterTitle}>{selectedAdhkar.text}</Text>

          <View style={styles.counterDisplay}>
            <Text style={styles.counterNumber}>{counter}</Text>
            <Text style={styles.counterTotal}>/ {selectedAdhkar.count}</Text>
          </View>

          <View style={styles.counterButtons}>
            <TouchableOpacity
              style={styles.resetButton}
              onPress={handleReset}
              activeOpacity={0.7}
            >
              <Text style={styles.resetButtonText}>إعادة تعيين</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[
                styles.incrementButton,
                counter === selectedAdhkar.count && styles.completedButton,
              ]}
              onPress={handleIncrement}
              activeOpacity={0.7}
            >
              <Text style={styles.incrementButtonText}>
                {counter === selectedAdhkar.count ? "✓ تم" : "زيادة"}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 20,
    backgroundColor: colors.primary,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: "700",
    color: colors.text,
    marginBottom: 5,
    textAlign: "right",
  },
  headerSubtitle: {
    fontSize: 13,
    color: colors.textSecondary,
    textAlign: "right",
  },
  tabsContainer: {
    flexDirection: "row",
    backgroundColor: colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: colors.surfaceLight,
  },
  tab: {
    flex: 1,
    paddingVertical: 15,
    alignItems: "center",
    borderBottomWidth: 3,
    borderBottomColor: "transparent",
  },
  activeTab: {
    borderBottomColor: colors.secondary,
  },
  tabText: {
    fontSize: 14,
    fontWeight: "600",
    color: colors.textSecondary,
  },
  activeTabText: {
    color: colors.secondary,
  },
  adhkarListContainer: {
    paddingHorizontal: 15,
    paddingVertical: 15,
  },
  adhkarItem: {
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: 15,
    marginBottom: 12,
    borderLeftWidth: 3,
    borderLeftColor: colors.primary,
  },
  selectedAdhkar: {
    backgroundColor: colors.surfaceLight,
    borderLeftColor: colors.secondary,
  },
  adhkarText: {
    fontSize: 14,
    color: colors.text,
    lineHeight: 22,
    textAlign: "right",
    marginBottom: 10,
  },
  adhkarFooter: {
    alignItems: "flex-end",
  },
  countText: {
    fontSize: 12,
    color: colors.secondary,
    fontWeight: "600",
  },
  counterContainer: {
    backgroundColor: colors.surface,
    borderTopWidth: 1,
    borderTopColor: colors.surfaceLight,
    padding: 20,
    alignItems: "center",
  },
  counterTitle: {
    fontSize: 14,
    color: colors.textSecondary,
    marginBottom: 20,
    textAlign: "center",
    lineHeight: 20,
  },
  counterDisplay: {
    flexDirection: "row",
    alignItems: "baseline",
    marginBottom: 30,
  },
  counterNumber: {
    fontSize: 72,
    fontWeight: "700",
    color: colors.secondary,
  },
  counterTotal: {
    fontSize: 24,
    color: colors.textSecondary,
    marginLeft: 10,
  },
  counterButtons: {
    flexDirection: "row",
    gap: 15,
    width: "100%",
  },
  resetButton: {
    flex: 1,
    paddingVertical: 15,
    backgroundColor: colors.surfaceLight,
    borderRadius: 10,
    alignItems: "center",
    borderWidth: 1,
    borderColor: colors.primary,
  },
  resetButtonText: {
    fontSize: 14,
    fontWeight: "600",
    color: colors.text,
  },
  incrementButton: {
    flex: 1,
    paddingVertical: 15,
    backgroundColor: colors.primary,
    borderRadius: 10,
    alignItems: "center",
  },
  completedButton: {
    backgroundColor: colors.success,
  },
  incrementButtonText: {
    fontSize: 14,
    fontWeight: "700",
    color: colors.text,
  },
});
