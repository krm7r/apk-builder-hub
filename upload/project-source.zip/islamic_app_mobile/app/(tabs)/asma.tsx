import React, { useState } from "react";
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  TextInput,
  Dimensions,
} from "react-native";
import { colors } from "@/app/constants/colors";
import { asmaAlHusna } from "@/app/data/islamicData";

const { width } = Dimensions.get("window");

export default function AsmaScreen() {
  const [searchText, setSearchText] = useState("");
  const [selectedAsma, setSelectedAsma] = useState(null);

  const filteredAsma = asmaAlHusna.filter(
    (asma) =>
      asma.name.includes(searchText) ||
      asma.meaning.includes(searchText)
  );

  const renderAsmaItem = ({ item }) => (
    <TouchableOpacity
      style={[
        styles.asmaItem,
        selectedAsma?.id === item.id && styles.selectedAsma,
      ]}
      onPress={() => setSelectedAsma(item)}
      activeOpacity={0.7}
    >
      <View style={styles.asmaContent}>
        <Text style={styles.asmaName}>{item.name}</Text>
        <Text style={styles.asmaMeaning}>{item.meaning}</Text>
      </View>
      <View style={styles.asmaNumber}>
        <Text style={styles.asmaNumberText}>{item.id}</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      {/* رأس الصفحة */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>الأسماء الحسنى</Text>
        <Text style={styles.headerSubtitle}>99 اسماً من أسماء الله الحسنى</Text>
      </View>

      {/* شريط البحث */}
      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="ابحث عن اسم..."
          placeholderTextColor={colors.textTertiary}
          value={searchText}
          onChangeText={setSearchText}
        />
      </View>

      {/* قائمة الأسماء */}
      <FlatList
        data={filteredAsma}
        renderItem={renderAsmaItem}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={styles.listContent}
        scrollEnabled={true}
      />

      {/* تفاصيل الاسم المختار */}
      {selectedAsma && (
        <View style={styles.detailsContainer}>
          <Text style={styles.detailsName}>{selectedAsma.name}</Text>
          <Text style={styles.detailsMeaning}>{selectedAsma.meaning}</Text>
          <View style={styles.detailsNumber}>
            <Text style={styles.detailsNumberLabel}>الاسم رقم</Text>
            <Text style={styles.detailsNumberValue}>{selectedAsma.id}</Text>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 20,
    backgroundColor: colors.primary,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: "700",
    color: colors.text,
    marginBottom: 5,
    textAlign: "right",
  },
  headerSubtitle: {
    fontSize: 13,
    color: colors.textSecondary,
    textAlign: "right",
  },
  searchContainer: {
    paddingHorizontal: 15,
    paddingVertical: 15,
    backgroundColor: colors.surface,
  },
  searchInput: {
    backgroundColor: colors.surfaceLight,
    borderRadius: 10,
    paddingHorizontal: 15,
    paddingVertical: 12,
    color: colors.text,
    textAlign: "right",
    borderWidth: 1,
    borderColor: colors.primary,
  },
  listContent: {
    paddingHorizontal: 15,
    paddingTop: 10,
    paddingBottom: 20,
  },
  asmaItem: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: 15,
    marginBottom: 10,
    borderLeftWidth: 3,
    borderLeftColor: colors.primary,
  },
  selectedAsma: {
    backgroundColor: colors.surfaceLight,
    borderLeftColor: colors.secondary,
  },
  asmaContent: {
    flex: 1,
    marginRight: 10,
  },
  asmaName: {
    fontSize: 18,
    fontWeight: "700",
    color: colors.secondary,
    textAlign: "right",
    marginBottom: 5,
  },
  asmaMeaning: {
    fontSize: 12,
    color: colors.textSecondary,
    textAlign: "right",
  },
  asmaNumber: {
    width: 45,
    height: 45,
    borderRadius: 22.5,
    backgroundColor: colors.primary,
    justifyContent: "center",
    alignItems: "center",
  },
  asmaNumberText: {
    fontSize: 14,
    fontWeight: "700",
    color: colors.text,
  },
  detailsContainer: {
    backgroundColor: colors.surface,
    borderTopWidth: 1,
    borderTopColor: colors.surfaceLight,
    padding: 20,
    alignItems: "center",
  },
  detailsName: {
    fontSize: 32,
    fontWeight: "700",
    color: colors.secondary,
    marginBottom: 15,
  },
  detailsMeaning: {
    fontSize: 14,
    color: colors.text,
    textAlign: "center",
    lineHeight: 22,
    marginBottom: 20,
  },
  detailsNumber: {
    alignItems: "center",
  },
  detailsNumberLabel: {
    fontSize: 12,
    color: colors.textSecondary,
    marginBottom: 5,
  },
  detailsNumberValue: {
    fontSize: 24,
    fontWeight: "700",
    color: colors.primary,
  },
});

