import React, { useState } from "react";
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  TextInput,
} from "react-native";
import { colors } from "@/app/constants/colors";
import {
  gregorianToHijri,
  hijriToGregorian,
  formatHijriDateArabic,
  formatDateArabic,
} from "@/app/utils/helpers";
import { hijriMonths } from "@/app/data/islamicData";

const { width } = Dimensions.get("window");

export default function HijriScreen() {
  const today = new Date();
  const hijriToday = gregorianToHijri(today);

  const [gregorianDate, setGregorianDate] = useState(formatDateArabic(today));
  const [hijriDate, setHijriDate] = useState(
    formatHijriDateArabic(hijriToday.year, hijriToday.month, hijriToday.day)
  );
  const [selectedMonth, setSelectedMonth] = useState(hijriToday.month);

  const handleConvertToHijri = () => {
    const today = new Date();
    const hijri = gregorianToHijri(today);
    setHijriDate(formatHijriDateArabic(hijri.year, hijri.month, hijri.day));
  };

  const handleConvertToGregorian = () => {
    const today = new Date();
    setGregorianDate(formatDateArabic(today));
  };

  return (
    <View style={styles.container}>
      {/* رأس الصفحة */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>التقويم الهجري</Text>
        <Text style={styles.headerSubtitle}>تحويل التواريخ الهجرية والميلادية</Text>
      </View>

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* التاريخ الحالي */}
        <View style={styles.currentDateCard}>
          <Text style={styles.currentDateLabel}>التاريخ اليوم</Text>
          <View style={styles.dateRow}>
            <View style={styles.dateColumn}>
              <Text style={styles.dateColumnLabel}>الميلادي</Text>
              <Text style={styles.dateColumnValue}>{formatDateArabic(today)}</Text>
            </View>
            <View style={styles.dateDivider} />
            <View style={styles.dateColumn}>
              <Text style={styles.dateColumnLabel}>الهجري</Text>
              <Text style={styles.dateColumnValue}>
                {formatHijriDateArabic(
                  hijriToday.year,
                  hijriToday.month,
                  hijriToday.day
                )}
              </Text>
            </View>
          </View>
        </View>

        {/* الأشهر الهجرية */}
        <Text style={styles.sectionTitle}>الأشهر الهجرية</Text>
        <View style={styles.monthsGrid}>
          {hijriMonths.map((month) => (
            <TouchableOpacity
              key={month.id}
              style={[
                styles.monthItem,
                selectedMonth === month.id && styles.selectedMonth,
              ]}
              onPress={() => setSelectedMonth(month.id)}
              activeOpacity={0.7}
            >
              <Text style={styles.monthName}>{month.name}</Text>
              <Text style={styles.monthDays}>{month.days} يوم</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* معلومات الشهر المختار */}
        {selectedMonth && (
          <View style={styles.monthDetailsCard}>
            <Text style={styles.monthDetailsTitle}>
              {hijriMonths[selectedMonth - 1]?.name}
            </Text>
            <View style={styles.monthDetailsInfo}>
              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>عدد الأيام</Text>
                <Text style={styles.infoValue}>
                  {hijriMonths[selectedMonth - 1]?.days}
                </Text>
              </View>
              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>رقم الشهر</Text>
                <Text style={styles.infoValue}>{selectedMonth}</Text>
              </View>
            </View>
          </View>
        )}

        {/* معلومات إضافية */}
        <View style={styles.infoCard}>
          <Text style={styles.infoCardTitle}>معلومات عن التقويم الهجري</Text>
          <Text style={styles.infoCardText}>
            التقويم الهجري هو التقويم الإسلامي الذي يعتمد على حركة القمر، وتبدأ السنة الهجرية بهجرة النبي محمد صلى الله عليه وسلم من مكة إلى المدينة.
          </Text>
          <Text style={styles.infoCardText}>
            السنة الهجرية تتكون من 12 شهراً قمرياً، وعدد أيامها 354 أو 355 يوماً.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 20,
    backgroundColor: colors.primary,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: "700",
    color: colors.text,
    marginBottom: 5,
    textAlign: "right",
  },
  headerSubtitle: {
    fontSize: 13,
    color: colors.textSecondary,
    textAlign: "right",
  },
  scrollContent: {
    paddingBottom: 30,
  },
  currentDateCard: {
    marginHorizontal: 15,
    marginTop: 20,
    padding: 20,
    backgroundColor: colors.surface,
    borderRadius: 15,
    borderLeftWidth: 4,
    borderLeftColor: colors.secondary,
  },
  currentDateLabel: {
    fontSize: 14,
    fontWeight: "600",
    color: colors.secondary,
    marginBottom: 15,
    textAlign: "right",
  },
  dateRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  dateColumn: {
    flex: 1,
    alignItems: "center",
  },
  dateColumnLabel: {
    fontSize: 12,
    color: colors.textSecondary,
    marginBottom: 5,
  },
  dateColumnValue: {
    fontSize: 14,
    fontWeight: "700",
    color: colors.text,
    textAlign: "center",
  },
  dateDivider: {
    width: 1,
    height: 40,
    backgroundColor: colors.surfaceLight,
    marginHorizontal: 15,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: colors.text,
    marginHorizontal: 15,
    marginTop: 25,
    marginBottom: 15,
    textAlign: "right",
  },
  monthsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    paddingHorizontal: 15,
    marginBottom: 20,
    justifyContent: "space-between",
  },
  monthItem: {
    width: (width - 45) / 2,
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: 15,
    marginBottom: 10,
    alignItems: "center",
    borderWidth: 1,
    borderColor: colors.primary,
  },
  selectedMonth: {
    backgroundColor: colors.surfaceLight,
    borderColor: colors.secondary,
  },
  monthName: {
    fontSize: 14,
    fontWeight: "600",
    color: colors.text,
    marginBottom: 5,
    textAlign: "center",
  },
  monthDays: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  monthDetailsCard: {
    marginHorizontal: 15,
    marginBottom: 20,
    padding: 18,
    backgroundColor: colors.surface,
    borderRadius: 15,
    borderLeftWidth: 4,
    borderLeftColor: colors.secondary,
  },
  monthDetailsTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: colors.secondary,
    marginBottom: 15,
    textAlign: "right",
  },
  monthDetailsInfo: {
    flexDirection: "row",
    justifyContent: "space-around",
  },
  infoItem: {
    alignItems: "center",
  },
  infoLabel: {
    fontSize: 12,
    color: colors.textSecondary,
    marginBottom: 5,
  },
  infoValue: {
    fontSize: 18,
    fontWeight: "700",
    color: colors.primary,
  },
  infoCard: {
    marginHorizontal: 15,
    marginBottom: 20,
    padding: 18,
    backgroundColor: colors.surfaceLight,
    borderRadius: 15,
    borderTopWidth: 2,
    borderTopColor: colors.accent,
  },
  infoCardTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: colors.accent,
    marginBottom: 12,
    textAlign: "right",
  },
  infoCardText: {
    fontSize: 13,
    color: colors.textSecondary,
    lineHeight: 20,
    marginBottom: 10,
    textAlign: "right",
  },
});

