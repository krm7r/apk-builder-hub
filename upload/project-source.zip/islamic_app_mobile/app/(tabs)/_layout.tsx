import { Tabs } from 'expo-router';
import React from 'react';
import { colors } from '@/app/constants/colors';

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: colors.secondary,
        tabBarInactiveTintColor: colors.textTertiary,
        headerShown: false,
        tabBarStyle: {
          backgroundColor: colors.surface,
          borderTopColor: colors.surfaceLight,
          borderTopWidth: 1,
        },
        tabBarLabelStyle: {
          fontSize: 11,
          fontWeight: '600',
        },
      }}>
      <Tabs.Screen
        name="index"
        options={{
          title: 'الرئيسية',
          tabBarLabel: 'الرئيسية',
          tabBarIcon: ({ color }) => <Text style={{ fontSize: 20 }}>🏠</Text>,
        }}
      />
      <Tabs.Screen
        name="quran"
        options={{
          title: 'القرآن',
          tabBarLabel: 'القرآن',
          tabBarIcon: ({ color }) => <Text style={{ fontSize: 20 }}>📖</Text>,
        }}
      />
      <Tabs.Screen
        name="prayers"
        options={{
          title: 'الصلاة',
          tabBarLabel: 'الصلاة',
          tabBarIcon: ({ color }) => <Text style={{ fontSize: 20 }}>⏰</Text>,
        }}
      />
      <Tabs.Screen
        name="qibla"
        options={{
          title: 'القبلة',
          tabBarLabel: 'القبلة',
          tabBarIcon: ({ color }) => <Text style={{ fontSize: 20 }}>🧭</Text>,
        }}
      />
      <Tabs.Screen
        name="adhkar"
        options={{
          title: 'الأذكار',
          tabBarLabel: 'الأذكار',
          tabBarIcon: ({ color }) => <Text style={{ fontSize: 20 }}>📿</Text>,
        }}
      />
      <Tabs.Screen
        name="hijri"
        options={{
          title: 'التقويم',
          tabBarLabel: 'التقويم',
          tabBarIcon: ({ color }) => <Text style={{ fontSize: 20 }}>📅</Text>,
        }}
      />
      <Tabs.Screen
        name="asma"
        options={{
          title: 'الأسماء',
          tabBarLabel: 'الأسماء',
          tabBarIcon: ({ color }) => <Text style={{ fontSize: 20 }}>✨</Text>,
        }}
      />
    </Tabs>
  );
}

import { Text } from 'react-native';

