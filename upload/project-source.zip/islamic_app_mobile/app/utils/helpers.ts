const hijriMonthNames = [
  "محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة",
  "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة",
];

export function gregorianToHijri(date: Date) {
  const parts = new Intl.DateTimeFormat("en-u-ca-islamic", {
    day: "numeric",
    month: "numeric",
    year: "numeric",
  }).formatToParts(date);
  const value = (type: string) => Number(parts.find((part) => part.type === type)?.value ?? 0);
  return { year: value("year"), month: value("month"), day: value("day") };
}

export function hijriToGregorian(year: number, month: number, day: number) {
  // التحويل الدقيق بين التقويمين يتطلب بيانات فلكية؛ هذه قيمة احتياطية للشاشة الحالية.
  return new Date(year, Math.max(0, month - 1), day);
}

export function formatHijriDateArabic(year: number, month: number, day: number) {
  return `${day || ""} ${hijriMonthNames[Math.max(0, month - 1)] ?? ""} ${year || ""} هـ`.trim();
}

export function formatDateArabic(date: Date) {
  return new Intl.DateTimeFormat("ar-EG", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(date);
}

export function formatTime(hours: number, minutes: number) {
  return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
}

export function calculateTimeUntilPrayer(time: { hours: number; minutes: number }) {
  const now = new Date();
  const target = new Date(now);
  target.setHours(time.hours, time.minutes, 0, 0);
  if (target <= now) target.setDate(target.getDate() + 1);
  const seconds = Math.floor((target.getTime() - now.getTime()) / 1000);
  return {
    hours: Math.floor(seconds / 3600),
    minutes: Math.floor((seconds % 3600) / 60),
    seconds: seconds % 60,
  };
}

export function calculateQiblaDirection(latitude: number, longitude: number) {
  const kaabaLatitude = 21.4225 * (Math.PI / 180);
  const kaabaLongitude = 39.8262 * (Math.PI / 180);
  const sourceLatitude = latitude * (Math.PI / 180);
  const sourceLongitude = longitude * (Math.PI / 180);
  const deltaLongitude = kaabaLongitude - sourceLongitude;
  const bearing = Math.atan2(
    Math.sin(deltaLongitude),
    Math.cos(sourceLatitude) * Math.tan(kaabaLatitude) - Math.sin(sourceLatitude) * Math.cos(deltaLongitude),
  );
  return (bearing * (180 / Math.PI) + 360) % 360;
}
