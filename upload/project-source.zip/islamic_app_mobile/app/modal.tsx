import { Link } from "expo-router";
import { StyleSheet, Text, View } from "react-native";

import { colors } from "@/app/constants/colors";

export default function ModalScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>نافذة معلومات</Text>
      <Link href="/" dismissTo style={styles.link}>العودة إلى الرئيسية</Link>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 20,
    backgroundColor: colors.background,
  },
  title: {
    marginBottom: 15,
    fontSize: 20,
    fontWeight: "700",
    color: colors.text,
  },
  link: {
    color: colors.secondary,
    fontSize: 16,
  },
});
