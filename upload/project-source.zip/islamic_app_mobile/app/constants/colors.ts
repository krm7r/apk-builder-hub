export const colors = {
  background: "#0B1220",
  surface: "#162033",
  surfaceLight: "#22304A",
  primary: "#146C5A",
  secondary: "#F4C15D",
  accent: "#6EE7B7",
  success: "#34D399",
  text: "#F8FAFC",
  textSecondary: "#CBD5E1",
  textTertiary: "#94A3B8",
} as const;
